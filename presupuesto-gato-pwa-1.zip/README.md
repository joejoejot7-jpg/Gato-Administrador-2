# Gato Administrador — PWA

App de presupuesto instalable (Bs/USD), sin dependencias externas: es HTML + CSS + JS puro.

## Probarla en tu computador

Los Service Workers (lo que permite instalar la app y usarla offline) **no funcionan abriendo el archivo directamente con doble clic** (file://). Necesitas un servidor local:

```bash
cd presupuesto-gato-pwa
python3 -m http.server 8000
# o: npx serve .
```

Luego abre `http://localhost:8000` en el navegador.

## Instalarla como app (PWA real)

Para que el botón "Instalar app" / "Agregar a pantalla de inicio" aparezca en el celular, la app debe servirse por **HTTPS** (localhost también cuenta, pero solo en tu propia computadora). Opciones gratis para subirla:

- **Netlify Drop**: arrastra la carpeta en https://app.netlify.com/drop
- **GitHub Pages**: sube estos archivos a un repositorio y activa Pages
- **Vercel**: `vercel` desde la carpeta del proyecto

Una vez publicada, entra a la URL desde el celular (Chrome/Safari) y usa "Agregar a pantalla de inicio" — quedará como una app normal, con ícono de gato, pantalla completa y sin la barra del navegador.

## Qué guarda y qué no

- Todo tu presupuesto (categorías, productos, tasa) se guarda en el propio dispositivo con `localStorage` — no se sube a ningún servidor.
- La tasa BCV se actualiza manualmente; la app no puede consultar el BCV en vivo.
- Los recordatorios diarios usan notificaciones del navegador. Funcionan mientras la app/pestaña siga abierta (aunque esté en segundo plano); los navegadores no permiten notificaciones programadas con la app totalmente cerrada.

## Archivos

- `index.html` — estructura y estilos
- `app.js` — toda la lógica (categorías, calculadora, gráfica, factura, recordatorios)
- `manifest.json` — metadata de instalación
- `sw.js` — service worker (caché offline)
- `icons/` — íconos de la app
