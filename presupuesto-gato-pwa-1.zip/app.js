/* Gato Administrador — PWA, vanilla JS, sin dependencias externas */

const STORAGE_KEY = "presupuestoGatoState_v1";
const PALETTE = ["#4FA8FF", "#82CFFF", "#1E5FA8", "#00C2CC", "#2E86DE", "#6DD5FA", "#0A3D62", "#3867D6"];
const uid = () => Math.random().toString(36).slice(2, 10);
const todayISO = () => new Date().toISOString().slice(0, 10);
const fmt = (n, c) =>
  c === "USD"
    ? `$${(n || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
    : `Bs ${(n || 0).toLocaleString("es-VE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

function seedState() {
  const rate = 700.22;
  return {
    rate,
    tab: "inicio",
    reminderOn: false,
    reminderHour: 9,
    lastNotifiedDate: null,
    categories: [
      {
        id: uid(), name: "Comida", color: PALETTE[0],
        products: [
          { id: uid(), name: "Mercado semanal", usd: 35, bs: 35 * rate, date: todayISO(), paid: true },
          { id: uid(), name: "Delivery", usd: 8, bs: 8 * rate, date: todayISO(), paid: false },
        ],
      },
      {
        id: uid(), name: "Transporte", color: PALETTE[1],
        products: [{ id: uid(), name: "Gasolina", usd: 12, bs: 12 * rate, date: todayISO(), paid: false }],
      },
      {
        id: uid(), name: "Servicios", color: PALETTE[2],
        products: [
          { id: uid(), name: "Internet", usd: 20, bs: 20 * rate, date: todayISO(), paid: true },
          { id: uid(), name: "Electricidad", usd: 10, bs: 10 * rate, date: todayISO(), paid: false },
        ],
      },
    ],
  };
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return seedState();
}

let state = loadState();
let calc = { expr: "", currency: "USD", raw: null, resultUsd: null, resultBs: null, justEquals: false };
let invoiceUrl = null;
let toastTimer = null;

function persist() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2200);
}

function totals() {
  let usd = 0, bs = 0, paidUsd = 0, pendingUsd = 0;
  state.categories.forEach((c) =>
    c.products.forEach((p) => {
      usd += p.usd;
      bs += p.bs;
      if (p.paid) paidUsd += p.usd; else pendingUsd += p.usd;
    })
  );
  return { usd, bs, paidUsd, pendingUsd };
}

/* ---------- render helpers ---------- */
function catIcon() {
  return `
  <svg viewBox="0 0 100 100" width="52" height="52">
    <ellipse cx="82" cy="70" rx="6" ry="16" fill="#82CFFF" class="tail"/>
    <ellipse cx="50" cy="66" rx="30" ry="26" fill="#FFFFFF" stroke="#0B1F3A" stroke-width="2.5"/>
    <path d="M30 34 L22 10 L44 28 Z" fill="#FFFFFF" stroke="#0B1F3A" stroke-width="2.5"/>
    <path d="M70 34 L78 10 L56 28 Z" fill="#FFFFFF" stroke="#0B1F3A" stroke-width="2.5"/>
    <circle cx="50" cy="40" r="24" fill="#FFFFFF" stroke="#0B1F3A" stroke-width="2.5"/>
    <ellipse cx="42" cy="40" rx="2.6" ry="3.4" fill="#0B1F3A" class="blink"/>
    <ellipse cx="58" cy="40" rx="2.6" ry="3.4" fill="#0B1F3A" class="blink"/>
    <path d="M47 46 L53 46 L50 49 Z" fill="#FB7185"/>
    <path d="M50 49 Q46 54 41 51 M50 49 Q54 54 59 51" stroke="#0B1F3A" stroke-width="1.6" fill="none" stroke-linecap="round"/>
    <circle cx="50" cy="22" r="7" fill="#4FA8FF" stroke="#0B1F3A" stroke-width="2"/>
    <text x="50" y="25" font-size="8" text-anchor="middle" fill="#0B1F3A" font-weight="bold">Bs</text>
    <ellipse cx="26" cy="58" rx="6" ry="9" fill="#FFFFFF" stroke="#0B1F3A" stroke-width="2.2" class="paw"/>
  </svg>`;
}

function donutSVG(data) {
  const total = data.reduce((s, d) => s + d.value, 0);
  const r = 60, cx = 70, cy = 70, C = 2 * Math.PI * r;
  let offset = 0;
  const segs = data.map((d) => {
    const frac = total ? d.value / total : 0;
    const dash = frac * C;
    const seg = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${d.color}" stroke-width="20"
      stroke-dasharray="${dash} ${C - dash}" stroke-dashoffset="${-offset}" class="donut-seg"
      transform="rotate(-90 ${cx} ${cy})"></circle>`;
    offset += dash;
    return seg;
  });
  return `<svg viewBox="0 0 140 140" width="100%" height="220">${segs.join("")}</svg>`;
}

function renderHeader() {
  const t = totals();
  return `
  <div class="header">
    <div class="header-row">
      ${catIcon()}
      <div class="header-title">
        <div class="app-name">Gato Administrador</div>
        <div class="app-sub">↻ Tasa BCV manual — actualízala cada día</div>
      </div>
      <button id="btn-reminder" class="icon-btn ${state.reminderOn ? "on" : ""}" title="Recordatorio diario">🔔</button>
    </div>
    <div class="rate-card">
      <span>Tasa BCV (Bs por USD)</span>
      <input id="rate-input" type="number" value="${state.rate}" step="0.01" />
    </div>
    ${state.reminderOn ? `
    <div class="reminder-row">
      ⏰ Hora del recordatorio:
      <select id="reminder-hour">
        ${Array.from({ length: 24 }, (_, i) => `<option value="${i}" ${i === state.reminderHour ? "selected" : ""}>${i}:00</option>`).join("")}
      </select>
      <span class="dim">(la app debe permanecer abierta)</span>
    </div>` : ""}
  </div>`;
}

function renderInicio() {
  const t = totals();
  const chartData = state.categories
    .map((c) => ({ name: c.name, color: c.color, value: c.products.reduce((s, p) => s + p.usd, 0) }))
    .filter((d) => d.value > 0);
  return `
  <div class="pop">
    <div class="hero-card pulse">
      <div class="hero-label">Presupuesto total (suma de productos)</div>
      <div class="hero-usd num">${fmt(t.usd, "USD")}</div>
      <div class="hero-bs num">${fmt(t.bs, "Bs")}</div>
    </div>
    <div class="grid2">
      <div class="stat-card paid">
        <div class="stat-label">Pagado</div>
        <div class="stat-value num">${fmt(t.paidUsd, "USD")}</div>
      </div>
      <div class="stat-card pending">
        <div class="stat-label">Pendiente</div>
        <div class="stat-value num">${fmt(t.pendingUsd, "USD")}</div>
      </div>
    </div>
    <div class="card">
      <div class="card-title">Gasto por categoría</div>
      ${chartData.length === 0
        ? `<div class="empty">Agrega productos para ver la gráfica</div>`
        : `<div class="donut-wrap">${donutSVG(chartData)}</div>
           <div class="legend">
            ${chartData.map((d) => {
              const pct = (d.value / chartData.reduce((s, x) => s + x.value, 0) * 100).toFixed(0);
              return `<div class="legend-item"><span class="dot" style="background:${d.color}"></span>${d.name} · ${pct}%</div>`;
            }).join("")}
           </div>`}
    </div>
  </div>`;
}

function renderCategorias() {
  return `
  <div class="pop">
    <button id="btn-add-cat" class="btn-primary full">+ Nueva categoría</button>
    ${state.categories.map((c) => {
      const sum = c.products.reduce((s, p) => s + p.usd, 0);
      return `
      <div class="card cat-card" style="border-left:4px solid ${c.color}">
        <div class="cat-head">
          <div class="cat-name">${c.name}</div>
          <div class="cat-actions">
            <span class="num cat-sum" style="color:${c.color}">${fmt(sum, "USD")}</span>
            <button class="icon-btn-sm" data-remove-cat="${c.id}">🗑</button>
          </div>
        </div>
        <div class="prod-list">
          ${c.products.map((p) => `
            <div class="prod-row">
              <div>
                <div>${p.name}</div>
                <div class="dim small">${p.date}</div>
              </div>
              <div class="prod-right">
                <div class="num prod-amounts">
                  <div>${fmt(p.usd, "USD")}</div>
                  <div class="dim small">${fmt(p.bs, "Bs")}</div>
                </div>
                <button class="pill-toggle ${p.paid ? "paid" : "pending"}" data-toggle-paid="${c.id}|${p.id}" title="${p.paid ? "Pagado" : "Pendiente"}">✓</button>
                <button class="icon-btn-sm" data-remove-prod="${c.id}|${p.id}">✕</button>
              </div>
            </div>`).join("")}
        </div>
        <button class="btn-ghost full" data-add-prod="${c.id}">+ Agregar producto</button>
      </div>`;
    }).join("")}
  </div>`;
}

function renderCalculadora() {
  const other = calc.currency === "USD" ? "Bs" : "USD";
  return `
  <div class="card pop">
    <div class="calc-currency-row">
      <div class="dim small">Ingresando montos en:</div>
      <div class="currency-toggle">
        <button class="curr-btn ${calc.currency === "USD" ? "active" : ""}" data-currency="USD">USD</button>
        <button class="curr-btn ${calc.currency === "Bs" ? "active" : ""}" data-currency="Bs">Bs</button>
      </div>
    </div>
    <div class="calc-expr num">${calc.expr || "0"}</div>
    <div class="calc-result num">
      ${calc.raw !== null
        ? (typeof calc.raw === "number"
          ? `${fmt(calc.currency === "USD" ? calc.resultUsd : calc.resultBs, calc.currency)}`
          : calc.raw)
        : ""}
    </div>
    ${typeof calc.raw === "number" ? `
      <div class="calc-convert dim small">= ${fmt(calc.currency === "USD" ? calc.resultBs : calc.resultUsd, other)} <span class="tiny">(tasa BCV ${state.rate})</span></div>
    ` : ""}
    <div class="calc-grid">
      ${["7","8","9","/","4","5","6","*","1","2","3","-","C","0",".","+"].map((k) => `<button class="calc-key num" data-calc="${k}">${k}</button>`).join("")}
      <button class="calc-key eq" data-calc="=">=</button>
    </div>
    ${typeof calc.raw === "number" ? `<button id="btn-calc-save" class="btn-save full">+ Guardar resultado como producto</button>` : ""}
  </div>`;
}

function renderPendientes() {
  const rows = (paid) => state.categories.flatMap((c) => c.products.filter((p) => p.paid === paid).map((p) => ({ ...p, cat: c.name, catId: c.id, color: c.color })));
  const item = (p, paid) => `
    <div class="pend-row ${paid ? "paid" : "pending"}" style="border-left:3px solid ${p.color}">
      <div>
        <div class="pend-name">${p.name}</div>
        <div class="dim small">${p.cat} · ${p.date}</div>
      </div>
      <div class="prod-right">
        <div class="num prod-amounts"><div>${fmt(p.usd, "USD")}</div><div class="dim small">${fmt(p.bs, "Bs")}</div></div>
        <button class="mini-btn ${paid ? "toPending" : "toPaid"}" data-toggle-paid="${p.catId}|${p.id}">${paid ? "Marcar pendiente" : "Marcar pagado"}</button>
      </div>
    </div>`;
  return `
  <div class="pop">
    <div class="section-title">Pendientes</div>
    ${rows(false).map((p) => item(p, false)).join("") || `<div class="empty">Nada pendiente 🎉</div>`}
    <div class="section-title mt">Pagados</div>
    ${rows(true).map((p) => item(p, true)).join("") || `<div class="empty">Aún no hay pagos registrados</div>`}
  </div>`;
}

function renderExportar() {
  return `
  <div class="pop">
    <div class="card">
      <div class="card-title">🧾 Exportar factura como imagen</div>
      <p class="dim small">Genera una foto tipo factura con todos tus productos, montos en Bs/USD y su estado.</p>
      <button id="btn-gen-invoice" class="btn-primary full">Generar factura</button>
    </div>
    ${invoiceUrl ? `
    <div class="invoice-preview pop">
      <img src="${invoiceUrl}" alt="factura"/>
      <a href="${invoiceUrl}" download="factura-presupuesto.png" class="btn-download full">⬇ Descargar imagen</a>
    </div>` : ""}
  </div>`;
}

function renderModals() {
  return `<div id="modal-root"></div>`;
}

function render() {
  const app = document.getElementById("app");
  const content = {
    inicio: renderInicio, categorias: renderCategorias, calculadora: renderCalculadora,
    pendientes: renderPendientes, exportar: renderExportar,
  }[state.tab]();

  app.innerHTML = `
    ${renderHeader()}
    <div class="content">${content}</div>
    <div class="bottom-nav">
      ${[
        ["inicio", "🏠", "Inicio"], ["categorias", "💼", "Categorías"], ["calculadora", "🧮", "Calc"],
        ["pendientes", "☑️", "Estado"], ["exportar", "🧾", "Factura"],
      ].map(([id, icon, label]) => `
        <button class="nav-btn ${state.tab === id ? "active" : ""}" data-tab="${id}">
          <span class="nav-icon">${icon}</span><span class="nav-label">${label}</span>
        </button>`).join("")}
    </div>
    ${renderModals()}
    <div id="toast" class="toast"></div>
  `;
  attachEvents();
}

/* ---------- events ---------- */
function attachEvents() {
  document.querySelectorAll("[data-tab]").forEach((b) => b.onclick = () => { state.tab = b.dataset.tab; render(); });

  const rateInput = document.getElementById("rate-input");
  if (rateInput) rateInput.onchange = (e) => { state.rate = parseFloat(e.target.value) || 0; persist(); render(); };

  const remHour = document.getElementById("reminder-hour");
  if (remHour) remHour.onchange = (e) => { state.reminderHour = +e.target.value; persist(); };

  const btnReminder = document.getElementById("btn-reminder");
  if (btnReminder) btnReminder.onclick = toggleReminder;

  const btnAddCat = document.getElementById("btn-add-cat");
  if (btnAddCat) btnAddCat.onclick = () => openModal(categoryModal());

  document.querySelectorAll("[data-add-prod]").forEach((b) => b.onclick = () => openModal(productModal(b.dataset.addProd)));
  document.querySelectorAll("[data-remove-cat]").forEach((b) => b.onclick = () => {
    state.categories = state.categories.filter((c) => c.id !== b.dataset.removeCat);
    persist(); render();
  });
  document.querySelectorAll("[data-remove-prod]").forEach((b) => b.onclick = () => {
    const [catId, prodId] = b.dataset.removeProd.split("|");
    const cat = state.categories.find((c) => c.id === catId);
    cat.products = cat.products.filter((p) => p.id !== prodId);
    persist(); render();
  });
  document.querySelectorAll("[data-toggle-paid]").forEach((b) => b.onclick = () => {
    const [catId, prodId] = b.dataset.togglePaid.split("|");
    const cat = state.categories.find((c) => c.id === catId);
    const prod = cat.products.find((p) => p.id === prodId);
    prod.paid = !prod.paid;
    persist(); render();
  });

  document.querySelectorAll("[data-calc]").forEach((b) => b.onclick = () => pressCalc(b.dataset.calc));
  document.querySelectorAll("[data-currency]").forEach((b) => b.onclick = () => switchCurrency(b.dataset.currency));
  const btnCalcSave = document.getElementById("btn-calc-save");
  if (btnCalcSave) btnCalcSave.onclick = () => openModal(calcSaveModal());

  const btnGenInvoice = document.getElementById("btn-gen-invoice");
  if (btnGenInvoice) btnGenInvoice.onclick = () => { buildInvoice(); render(); };
}

function switchCurrency(cur) {
  if (cur === calc.currency) return;
  // Convert whatever is currently on screen so the person doesn't lose their place
  if (calc.raw !== null && typeof calc.raw === "number") {
    calc.currency = cur;
    calc.expr = String(cur === "USD" ? calc.resultUsd.toFixed(2) : calc.resultBs.toFixed(2));
    computeResult();
    calc.justEquals = true;
  } else {
    calc.currency = cur;
  }
  render();
}

function computeResult() {
  try {
    const clean = calc.expr.replace(/[^0-9+\-*/.()]/g, "");
    // eslint-disable-next-line no-new-func
    const val = Function(`"use strict"; return (${clean})`)();
    calc.raw = val;
    if (calc.currency === "USD") { calc.resultUsd = val; calc.resultBs = val * state.rate; }
    else { calc.resultBs = val; calc.resultUsd = val / state.rate; }
  } catch {
    calc.raw = "Error"; calc.resultUsd = null; calc.resultBs = null;
  }
}

function pressCalc(val) {
  if (val === "C") {
    calc = { expr: "", currency: calc.currency, raw: null, resultUsd: null, resultBs: null, justEquals: false };
    render(); return;
  }
  if (val === "=") {
    computeResult();
    calc.justEquals = true;
    render(); return;
  }
  const isDigit = /[0-9.]/.test(val);
  if (calc.justEquals) {
    if (isDigit) {
      calc.expr = val; // start a fresh number
    } else {
      // continue chaining from the previous result, e.g. 5+3= then +2=
      const prevRaw = typeof calc.raw === "number" ? calc.raw : 0;
      calc.expr = String(prevRaw) + val;
    }
    calc.justEquals = false;
    calc.raw = null;
  } else {
    calc.expr += val;
  }
  render();
}

/* ---------- modals ---------- */
function openModal(innerHtml) {
  const root = document.getElementById("modal-root");
  root.innerHTML = `<div class="modal-overlay" id="modal-overlay"><div class="modal pop" id="modal-box">${innerHtml}</div></div>`;
  document.getElementById("modal-overlay").onclick = (e) => { if (e.target.id === "modal-overlay") closeModal(); };
}
function closeModal() { document.getElementById("modal-root").innerHTML = ""; }

function categoryModal() {
  setTimeout(() => {
    document.getElementById("cat-save").onclick = () => {
      const name = document.getElementById("cat-name").value.trim();
      if (!name) return;
      state.categories.push({ id: uid(), name, color: PALETTE[state.categories.length % PALETTE.length], products: [] });
      persist(); closeModal(); render();
    };
  }, 0);
  return `
    <div class="modal-title">Nueva categoría</div>
    <input id="cat-name" class="input" placeholder="Ej. Educación" autofocus/>
    <button id="cat-save" class="btn-primary full mt">Crear</button>`;
}

function productModal(catId) {
  setTimeout(() => {
    const usdEl = document.getElementById("prod-usd"), bsEl = document.getElementById("prod-bs");
    usdEl.oninput = () => { const n = parseFloat(usdEl.value); bsEl.value = Number.isFinite(n) ? (n * state.rate).toFixed(2) : ""; };
    bsEl.oninput = () => { const n = parseFloat(bsEl.value); usdEl.value = Number.isFinite(n) ? (n / state.rate).toFixed(2) : ""; };
    document.getElementById("prod-save").onclick = () => {
      const name = document.getElementById("prod-name").value.trim() || "Producto";
      const usd = parseFloat(usdEl.value) || 0;
      const bs = parseFloat(bsEl.value) || usd * state.rate;
      const date = document.getElementById("prod-date").value || todayISO();
      const paid = document.getElementById("prod-paid").checked;
      const cat = state.categories.find((c) => c.id === catId);
      cat.products.push({ id: uid(), name, usd, bs, date, paid });
      persist(); closeModal(); render();
    };
  }, 0);
  return `
    <div class="modal-title">Nuevo producto</div>
    <input id="prod-name" class="input" placeholder="Nombre del producto"/>
    <div class="grid2 mt">
      <div><div class="dim small mb">Monto en USD</div><input id="prod-usd" type="number" class="input num" placeholder="0.00"/></div>
      <div><div class="dim small mb">Monto en Bs</div><input id="prod-bs" type="number" class="input num" placeholder="0.00"/></div>
    </div>
    <div class="dim tiny mt">Escribe en cualquiera de los dos campos: el otro se calcula con la tasa BCV, pero puedes ajustarlo si es distinto.</div>
    <input id="prod-date" type="date" class="input mt" value="${todayISO()}"/>
    <label class="checkbox-row"><input id="prod-paid" type="checkbox"/> Ya está pagado</label>
    <button id="prod-save" class="btn-primary full mt">Agregar</button>`;
}

function calcSaveModal() {
  const usd = calc.resultUsd, bs = calc.resultBs;
  setTimeout(() => {
    document.getElementById("calc-save-btn").onclick = () => {
      const catId = document.getElementById("calc-cat").value;
      const name = document.getElementById("calc-name").value.trim() || "Producto";
      const date = document.getElementById("calc-date").value || todayISO();
      const cat = state.categories.find((c) => c.id === catId);
      cat.products.push({ id: uid(), name, usd, bs, date, paid: false });
      persist(); closeModal();
      calc = { expr: "", currency: calc.currency, raw: null, resultUsd: null, resultBs: null, justEquals: false };
      render();
    };
  }, 0);
  return `
    <div class="modal-title">Guardar como producto</div>
    <div class="num calc-preview">${fmt(usd, "USD")}</div>
    <div class="num dim center">${fmt(bs, "Bs")}</div>
    <select id="calc-cat" class="input mt">
      ${state.categories.map((c) => `<option value="${c.id}">${c.name}</option>`).join("")}
    </select>
    <input id="calc-name" class="input mt" placeholder="Nombre del producto"/>
    <input id="calc-date" type="date" class="input mt" value="${todayISO()}"/>
    <button id="calc-save-btn" class="btn-primary full mt">Guardar</button>`;
}

/* ---------- reminders ---------- */
let reminderInterval = null;
function toggleReminder() {
  if (!state.reminderOn) {
    Notification.requestPermission().then((perm) => {
      if (perm !== "granted") { toast("Permiso de notificaciones denegado"); return; }
      state.reminderOn = true; persist(); render();
      startReminderLoop();
      toast("Recordatorio diario activado 🐾");
    });
  } else {
    state.reminderOn = false; persist(); render();
    clearInterval(reminderInterval);
  }
}
function startReminderLoop() {
  clearInterval(reminderInterval);
  reminderInterval = setInterval(() => {
    const now = new Date();
    const key = now.toISOString().slice(0, 10);
    if (now.getHours() === state.reminderHour && state.lastNotifiedDate !== key) {
      state.lastNotifiedDate = key; persist();
      const t = totals();
      const payload = { title: "🐱 Recordatorio de presupuesto", options: { body: `Pendiente por pagar: ${fmt(t.pendingUsd, "USD")}`, icon: "icons/icon-192.png" } };
      if (navigator.serviceWorker && navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({ type: "SHOW_NOTIFICATION", ...payload });
      } else if (Notification.permission === "granted") {
        new Notification(payload.title, payload.options);
      }
    }
  }, 30000);
}

/* ---------- invoice export ---------- */
function buildInvoice() {
  const rows = [];
  state.categories.forEach((c) => c.products.forEach((p) => rows.push({ cat: c.name, ...p })));
  const W = 720, rowH = 30;
  const H = 300 + rows.length * rowH + 140;
  const canvas = document.createElement("canvas");
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d");
  const grad = ctx.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, "#0B1F3A"); grad.addColorStop(1, "#123A66");
  ctx.fillStyle = grad; ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = "#F5F8FC"; ctx.fillRect(20, 20, W - 40, H - 40);
  ctx.fillStyle = "#0B1F3A"; ctx.font = "bold 28px system-ui";
  ctx.fillText("🐱 Factura de Presupuesto", 40, 62);
  ctx.font = "14px system-ui"; ctx.fillStyle = "#3A6EA5";
  ctx.fillText(`Fecha de emisión: ${new Date().toLocaleDateString("es-VE")}`, 40, 84);
  ctx.fillText(`Tasa BCV: ${state.rate.toLocaleString("es-VE")} Bs/USD`, 40, 102);
  let y = 140;
  ctx.fillStyle = "#0B1F3A"; ctx.font = "bold 15px system-ui";
  ctx.fillText("Categoría", 40, y); ctx.fillText("Producto", 190, y); ctx.fillText("Fecha", 380, y);
  ctx.fillText("Monto", 460, y); ctx.fillText("Estado", 600, y);
  ctx.strokeStyle = "#CFE4F7"; ctx.beginPath(); ctx.moveTo(40, y + 10); ctx.lineTo(W - 40, y + 10); ctx.stroke();
  y += 30; ctx.font = "13px system-ui";
  const t = totals();
  rows.forEach((r) => {
    ctx.fillStyle = "#0B1F3A";
    ctx.fillText(r.cat, 40, y);
    ctx.fillText(r.name.slice(0, 22), 190, y);
    ctx.fillText(r.date, 380, y);
    ctx.fillText(`$${r.usd.toFixed(2)} / Bs ${r.bs.toFixed(2)}`, 460, y);
    ctx.fillStyle = r.paid ? "#0F9D6E" : "#E1493F";
    ctx.fillText(r.paid ? "Pagado" : "Pendiente", 600, y);
    y += rowH;
  });
  y += 10;
  ctx.strokeStyle = "#CFE4F7"; ctx.beginPath(); ctx.moveTo(40, y); ctx.lineTo(W - 40, y); ctx.stroke();
  y += 30; ctx.font = "bold 18px system-ui"; ctx.fillStyle = "#0B1F3A";
  ctx.fillText(`Total presupuesto: $${t.usd.toFixed(2)}  (Bs ${t.bs.toFixed(2)})`, 40, y);
  y += 26; ctx.font = "14px system-ui"; ctx.fillStyle = "#0F9D6E";
  ctx.fillText(`Pagado: $${t.paidUsd.toFixed(2)}`, 40, y);
  ctx.fillStyle = "#E1493F";
  ctx.fillText(`Pendiente: $${t.pendingUsd.toFixed(2)}`, 220, y);
  invoiceUrl = canvas.toDataURL("image/png");
}

/* ---------- init ---------- */
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  });
}
if (state.reminderOn) startReminderLoop();
render();
